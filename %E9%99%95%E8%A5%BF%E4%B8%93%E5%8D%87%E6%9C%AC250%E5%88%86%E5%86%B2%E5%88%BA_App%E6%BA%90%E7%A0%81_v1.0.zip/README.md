# 陕西专升本250分冲刺 App（初始版）

## 当前功能
- 首页与学习进度概览
- 高等数学、大学英语课程
- Day 1 课程讲义、词汇
- 选择题练习、自动判分、答案解析
- 错题本自动收录与移除
- 本机 localStorage 保存学习进度
- PWA manifest + Service Worker，可添加到安卓主屏幕
- content.json 远程更新入口

## 重要说明
此交付物是可运行的 PWA 应用源文件，不是 APK。当前构建环境没有 Android SDK/Gradle，未能在此直接生成可安装 APK。要发布为 APK，需要用 Android Studio/Capacitor 或 Bubblewrap 包装，并在具备 Android SDK 的构建环境中编译签名。

## 本地预览
由于浏览器 Service Worker/PWA 需要 localhost 或 HTTPS，建议将目录部署到 HTTPS 静态托管服务。
可用任意静态网站托管：上传全部文件，确保 index.html 与 content.json 位于同一目录。
安卓 Chrome 打开部署地址 -> 浏览器菜单 -> 添加到主屏幕/安装应用。

## 更新课程
编辑 content.json，提升 version，重新部署。用户联网后刷新或进入进度页检查更新。
题目 answer 使用从 0 开始的选项索引。

## 后续扩展
目前只内置第一天基础课程和题目，尚未覆盖完整考纲。需要继续逐章制作课程、题库和模拟卷；正式考试政策和题型以陕西省教育考试院当年公告为准。
